<?php 
include('action.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>hotel accommodation</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="fontawesome-free-5.15.3-web/css/all.min.css">
</head>
<body>
     <?php if(isset($_SESSION['response'])){ ?>
   <div class="alert alert-<?= $_SESSION['res_type']; ?> alert-dismissible text-center">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
     <b class="text-success"><?= $_SESSION['response']; ?></b>
    </div>
      <?php } unset($_SESSION['response']); ?>

    <header class="header">
       <a href="#"></a>
        <nav class="navbar">
            <a href="accomodation.php">accommodation</a>
        </nav>
        <div class="icons">
            
            <div class="fas fa-user" id="myuser"></div>
            <div class="fas fa-search" id="serach-bar"></div>
            <div class="fas fa-bars" id="menu-bars"></div>
        </div>

        <div class="search-box">
            <input type="search" placeholder="search here">
        </div>
        
    </header>
<!-- background image -->

    
    <!-- background image ended -->

<!-- booking secton -->
<div class="book-section">
    <div class="inner-book">
        
            
        </div>
    </div>
    
</div>
<!--Booking-->
 <div class="our-rooms">
       <h1>Accommodations</h1>
       <div class="inner-rooms">
           <div class="room-box">

               <img src="imgaes/Single_bed.png" alt="">
               <div class="beds">
                   <span>Single Bed Room</span>
               </div>
               <div class="book-room-btn">
                <a href="single.php" class="book-room">Book now</a>
            </div>
           </div>

           <div class="room-box">
            <img src="imgaes/twin_bed.png" alt="">
            <div class="beds">
                <span>Twin Bed Room </span>
            </div>
            <div class="book-room-btn">

                <a href="twin.php" class="book-room">Book now</a>
            </div>
        </div>
    </div>
</div>



    <div class="our-rooms">
       <div class="inner-rooms">
           <div class="room-box">

               <img src="imgaes/double_bed.png" alt="">

               <div class="beds">
                   <span>Double Bed Room</span>
               </div>
               <div class="book-room-btn">
                <a href="double.php" class="book-room">Book now</a>
            </div>
           </div>

           <div class="room-box">
            <img src="imgaes/executive_bed.png" alt="">
            <div class="beds">
                <span>Excecutive Bed Room </span>
            </div>
            <div class="book-room-btn">
                <a href="executive.php" class="book-room">Book now</a>
            </div>
        </div>
    </div>


</div>

<!-- booking secton ended -->

<!-- award winning ended -->





    <script src="script.js"></script>
</body>
</html>