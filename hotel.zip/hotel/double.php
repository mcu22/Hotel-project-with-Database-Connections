<?php 
include('action.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>single room booking</title>
	<link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="fontawesome-free-5.15.3-web/css/all.min.css">
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</head>
<body>
     <?php if(isset($_SESSION['response'])){ ?>
   <div class="alert alert-<?= $_SESSION['res_type']; ?> alert-dismissible text-center">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
     <b class="text-success"><?= $_SESSION['response']; ?></b>
    </div>
      <?php } unset($_SESSION['response']); ?>

    <header class="header">
       <a href="#"></a>
        <nav class="navbar">
            <a href="accomodation.php">accommodation</a>
        </nav>
        <div class="icons">
            
            <div class="fas fa-user" id="myuser"></div>
            <div class="fas fa-search" id="serach-bar"></div>
            <div class="fas fa-bars" id="menu-bars"></div>
        </div>

        <div class="search-box">
            <input type="search" placeholder="search here">
        </div>
        
    </header>
    <div class="book-section">
    <div class="inner-book">
        
            
        </div>
    </div>
    
</div>
 <div class="our-rooms">
       <div class="inner-rooms">
           <div class="room-box">

               <img src="imgaes/double_bed.png" alt="">
               <div class="beds">
                  <!-- <span>Single Bed Room</span>-->
               </div>
              <!-- <div class="book-room-btn">
                <a href="#" class="book-room">Book now</a>
            </div>-->
           </div>

           <div class="room-box">
           <div id="booking" class="section">
    <div class="section-center">
        <div class="container">
            <div class="row">
                <div class="booking-form">
                    <div class="form-header">

                    	<!--Make Reservation-->
                        <h1>Make Double Bed Room Reservation</h1>
                    </div>
                     <form method="post" action="action.php" enctype="multipart/form-data">
                        <div class="form-group"> <input class="form-control" type="text" name="destination" placeholder="Country, ZIP, city..."> <span class="form-label">Destination</span> </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group"> <input class="form-control" type="date" name="idate" required> <span class="form-label">Check In</span> </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group"> <input class="form-control" type="date" name="cdate" required> <span class="form-label">Check out</span> </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group"> <select class="form-control" name="rooms" required>
                                        <option value="" selected hidden>no of rooms</option>
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                    </select> <span class="select-arrow"></span> <span class="form-label">Rooms</span> </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group"> <select class="form-control" name="adults" required>
                                        <option value="" selected hidden>no of adults</option>
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                    </select> <span class="select-arrow"></span> <span class="form-label">Adults</span> </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group"> <select class="form-control" name="children" required>
                                        <option value="" selected hidden>no of children</option>
                                        <option>0</option>
                                        <option>1</option>
                                        <option>2</option>
                                    </select> <span class="select-arrow"></span> <span class="form-label">Children</span> </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group"> <input class="form-control" type="email" name="email" placeholder="Enter your Email"> <span class="form-label">Email</span> </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group"> <input class="form-control" type="tel" name="phone" placeholder="Enter you Phone"> <span class="form-label">Phone</span> </div>
                            </div>
                        </div>
                        <div class="form-btn"> <button name="submit" class="submit-btn">Book Now</button> </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
            </div>
        </div>
    </div>
</div>

</body>
</html>