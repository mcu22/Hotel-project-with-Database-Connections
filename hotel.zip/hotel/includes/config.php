<?php
$servername = 'localhost';
$username = 'hotel_user';
$password = 'hotel@2022';
$dbname = 'hotel_db';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$conn = mysqli_connect($servername, $username, $password, $dbname);

if(!$conn){
    echo 'connection Error'.mysqli_connect_error();

}
?>