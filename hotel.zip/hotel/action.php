<?php 

session_start();

include('includes/config.php');


// INSERT RECORDS INTO DATABASE 
	$update=false;
	$destination="";
	$idate="";
	$cdate="";
	$rooms="";
	$adults="";
	$children="";
	$email="";
	$phone="";
	# code...
	

	if (isset($_POST['submit'])) {
	$id=$_POST['id'];
	$destination=$_POST['destination'];
	$idate=$_POST['idate'];
	$cdate=$_POST['cdate'];
	$rooms=$_POST['rooms'];
	$adults=$_POST['adults'];
	$children=$_POST['children'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];


/* Check if User Exist in the data base */
$check_email = mysqli_query($conn, "SELECT email FROM hotel_tbl where email = '$email' ");
if(mysqli_num_rows($check_email) > 0){
    echo('User Already exists');
 
}else{
	$email=$email;
}
   
   $query="INSERT INTO hotel_tbl(id,destination,idate,cdate,rooms,adults,children,email,phone)VALUES(?,?,?,?,?,?,?,?,?)";
	$stmt=$conn->prepare($query);
	$stmt->bind_param("ssssssssi",$id,$destination,$idate,$cdate,$rooms,$adults,$children,$email,$phone);
	$stmt->execute();
	header('Location:accomodation.php');
	$_SESSION['response']="Successfully Booked for Accomodation!";
	$_SESSION['res_type']="success";
	# code...

}
?>


